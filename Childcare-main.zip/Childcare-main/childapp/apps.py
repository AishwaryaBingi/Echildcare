from django.apps import AppConfig


class ChildappConfig(AppConfig):
    name = 'childapp'
