from django.contrib import admin
from childapp.models import register

    # Register your models her
admin.site.register(register)
